package parking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class UnParkTest {


     Actuator actuator;
    Sensor sensorA;
    Sensor sensorB;
    ArrayList<ParkingSpace> pSpaces;
    int simulationPosition;
    State simulationState;
    Car c;

    StreetFileReader reader;
    ArrayList<Integer> streetList;

    @BeforeEach 
    public void setup(){

        actuator = mock(Actuator.class);
        sensorA = mock(Sensor.class);
        sensorB = mock(Sensor.class);
        simulationPosition = 0;
        pSpaces = new ArrayList<>();
        simulationState = new State(simulationPosition, CarStatus.UNPARKED, pSpaces);
        simulationState = new State(simulationPosition, CarStatus.UNPARKED, pSpaces);
        c = new Car(sensorA, sensorB, simulationState, actuator);
        reader = new StreetFileReader();
        streetList = reader.readStreet("C:\\Users\\khaawa22\\Documents\\GitHub\\Networks-and-Testing-for-Embedded-Systems\\Street.txt");

        simulationPosition = c.getState().getPosition();
        when(actuator.getPosition()).thenAnswer(invocation -> simulationPosition);
        when(actuator.moveForward()).thenAnswer(invocation -> {
            if (simulationPosition >= 500) {
                return false;
            }
        
            simulationPosition++;
            return true;
        });

        when(actuator.moveBackward()).thenAnswer(invocation -> {
            if (simulationPosition <= 0) {
                return  false;
            }
            simulationPosition--;
            return true;
        });
        when(sensorA.getDistance()).thenAnswer(invocation -> {
            int p = streetList.get(simulationPosition);
            return new int [] {p,p,p,p,p};
        });
        when(sensorB.getDistance()).thenAnswer(invocation -> {
            int p = streetList.get(simulationPosition);
            return new int [] {p,p,p,p,p};
        });
    }

    
    @Test 
    public void ifTheCarIsParkedThenUnPark(){
        
        c.park(new FirstSuitableRoutine());
        c.unPark();

        assertEquals(c.getState().getParkStatus(), CarStatus.UNPARKED);
         for (int i = c.getState().getPosition(); i <= c.getState().getPosition() + 5; i++) {
            assertEquals(c.getState().getDetectedSpace().get(i).isTaken(), false);
        }
    }


    @Test 
    public void ifTheCarIsNotParkedThenUnPark(){
        State s = new State(100, CarStatus.UNPARKED, new ArrayList<>());
        Car   c = new Car(null, null, s);
        c.unPark();

        assertEquals(c.getState().getParkStatus(), CarStatus.UNPARKED);
    }
}
